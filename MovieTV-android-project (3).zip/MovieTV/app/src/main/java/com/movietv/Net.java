package com.movietv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Net {
    static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    static final LruCache<String, Bitmap> BMP = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    static final Map<String, String> POSTER = Collections.synchronizedMap(new HashMap<String, String>());

    static class Entry {
        String name, url, poster;
        boolean folder, video, image;
    }

    static byte[] bytes(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 5.1) MovieTV");
        InputStream in = c.getInputStream();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }

    static String get(String u) throws Exception { return new String(bytes(u), "UTF-8"); }

    static Bitmap bitmap(String u, int reqW) throws Exception {
        byte[] d = bytes(u);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(d, 0, d.length, o);
        int s = 1;
        while (o.outWidth / (s * 2) >= reqW) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        return BitmapFactory.decodeByteArray(d, 0, d.length, o);
    }

    static String decode(String s) {
        try { return URLDecoder.decode(s.replace("+", "%2B"), "UTF-8"); } catch (Exception e) { return s; }
    }

    static String lastSeg(String url) {
        String u = url;
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return decode(u.substring(u.lastIndexOf('/') + 1));
    }

    static String abs(String base, String href) {
        try {
            href = href.trim().replace("&amp;", "&");
            if (href.length() == 0 || href.startsWith("#") || href.startsWith("javascript") || href.startsWith("mailto")) return null;
            String a = new URL(new URL(base), href).toString();
            int h = a.indexOf('#'); if (h > 0) a = a.substring(0, h);
            return a;
        } catch (Exception e) { return null; }
    }

    private static final Pattern HREF = Pattern.compile("<a\\s[^>]*?href\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern LINK = Pattern.compile("<a\\s[^>]*?href\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    // ফোল্ডারের ভেতরের ফোল্ডার ও ফাইলের তালিকা
    static List<Entry> listing(String html, String base) {
        if (!base.endsWith("/")) base += "/";
        List<Entry> out = new ArrayList<Entry>();
        Set<String> seen = new LinkedHashSet<String>();
        Matcher m = HREF.matcher(html);
        while (m.find()) {
            String a = abs(base, m.group(1));
            if (a == null || a.indexOf('?') >= 0 || a.equals(base) || !a.startsWith(base) || !seen.add(a)) continue;
            Entry e = new Entry();
            e.url = a;
            e.folder = a.endsWith("/");
            e.name = lastSeg(a);
            String l = e.name.toLowerCase();
            e.video = !e.folder && MainActivity.isVideo(a);
            e.image = !e.folder && l.matches(".*\\.(jpe?g|png|webp)$");
            out.add(e);
        }
        return out;
    }

    // হোম পেজের ক্যাটাগরির বোতাম (লেখা + লিংক)
    static List<Entry> links(String html, String base) {
        List<Entry> out = new ArrayList<Entry>();
        Set<String> seen = new LinkedHashSet<String>();
        Matcher m = LINK.matcher(html);
        while (m.find()) {
            String a = abs(base, m.group(1));
            String t = m.group(2).replaceAll("<[^>]+>", "").replace("&amp;", "&").replaceAll("\\s+", " ").trim();
            if (a == null || t.length() < 2 || !a.startsWith("http") || a.equals(base) || !seen.add(a)) continue;
            Entry e = new Entry();
            e.url = a; e.name = t; e.folder = true;
            out.add(e);
        }
        return out;
    }

    static String firstImage(String folderUrl) {
        String c = POSTER.get(folderUrl);
        if (c != null) return c.length() == 0 ? null : c;
        String found = "";
        try {
            for (Entry e : listing(get(folderUrl), folderUrl)) if (e.image) { found = e.url; break; }
        } catch (Exception ignored) { }
        POSTER.put(folderUrl, found);
        return found.length() == 0 ? null : found;
    }

    // "Relationship Goals (2026) 720p AMZN [Dual Audio]" -> "Relationship Goals (2026)"
    static String clean(String name, boolean file) {
        if (file) name = name.replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
        int p = name.indexOf(" (");
        if (p > 0) {
            String t = name.substring(0, p);
            Matcher y = Pattern.compile("\\((\\d{4})\\)").matcher(name);
            if (y.find()) t += " (" + y.group(1) + ")";
            return t;
        }
        return name;
    }
}
