package com.movietv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class FolderActivity extends Activity {
    private final List<Net.Entry> items = new ArrayList<Net.Entry>();
    private GridView grid;
    private TextView status;
    private int cw;
    private String url;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        url = getIntent().getStringExtra("url");
        if (!url.endsWith("/")) url += "/";
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int pad = dp(28), gap = dp(14), cols = 6;
        cw = (dm.widthPixels - pad * 2 - gap * (cols - 1)) / cols - dp(12);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(MainActivity.BG);

        TextView title = new TextView(this);
        title.setText(getIntent().getStringExtra("title"));
        title.setTextColor(MainActivity.GOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(pad, dp(16), pad, dp(4));
        root.addView(title);

        status = new TextView(this);
        status.setText("লোড হচ্ছে...");
        status.setTextColor(MainActivity.DIM);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        status.setPadding(pad, dp(10), pad, 0);
        root.addView(status);

        grid = new GridView(this);
        grid.setNumColumns(cols);
        grid.setHorizontalSpacing(gap);
        grid.setVerticalSpacing(gap);
        grid.setPadding(pad, dp(10), pad, dp(20));
        grid.setClipToPadding(false);
        grid.setVerticalScrollBarEnabled(false);
        GradientDrawable sel = new GradientDrawable();
        sel.setColor(0x33F5B335);
        sel.setStroke(dp(4), MainActivity.GOLD);
        sel.setCornerRadius(dp(12));
        grid.setSelector(sel);
        grid.setDrawSelectorOnTop(true);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                Net.Entry e = items.get(pos);
                Intent i = new Intent(FolderActivity.this, e.folder ? FolderActivity.class : PlayerActivity.class);
                i.putExtra("url", e.url);
                i.putExtra("title", Net.clean(e.name, !e.folder));
                startActivity(i);
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);
        load();
    }

    private void webFallback() {
        Intent i = new Intent(this, WebActivity.class);
        i.putExtra("url", url);
        startActivity(i);
        finish();
    }

    private void load() {
        Net.POOL.execute(new Runnable() {
            @Override public void run() {
                List<Net.Entry> list = null;
                try { list = Net.listing(Net.get(url), url); } catch (Exception ignored) { }
                final List<Net.Entry> res = list;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isFinishing()) return;
                        if (res == null) { status.setText("সার্ভারে সংযোগ হচ্ছে না। ঠিকানা ও ওয়াইফাই দেখুন।"); return; }
                        String img = null;
                        for (Net.Entry e : res) if (e.image) { img = e.url; break; }
                        for (Net.Entry e : res) {
                            if (e.folder) items.add(e);
                            else if (e.video) { e.poster = img; items.add(e); }
                        }
                        if (items.isEmpty()) { webFallback(); return; }
                        status.setVisibility(View.GONE);
                        grid.setAdapter(new Adapter());
                        grid.requestFocus();
                    }
                });
            }
        });
    }

    static class Holder {
        FrameLayout poster; TextView ini, name; ImageView img; String key;
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int p) { return items.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override public View getView(int p, View v, ViewGroup parent) {
            Holder h;
            if (v == null) {
                LinearLayout box = new LinearLayout(FolderActivity.this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(6), dp(6), dp(6), dp(6));
                box.setLayoutParams(new GridView.LayoutParams(cw + dp(12), cw * 3 / 2 + dp(70)));
                h = new Holder();
                h.poster = new FrameLayout(FolderActivity.this);
                h.ini = new TextView(FolderActivity.this);
                h.ini.setTextColor(0xE6FFFFFF);
                h.ini.setTypeface(Typeface.DEFAULT_BOLD);
                h.ini.setGravity(Gravity.CENTER);
                h.poster.addView(h.ini, new FrameLayout.LayoutParams(-1, -1));
                h.img = new ImageView(FolderActivity.this);
                h.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                h.poster.addView(h.img, new FrameLayout.LayoutParams(-1, -1));
                box.addView(h.poster, new LinearLayout.LayoutParams(cw, cw * 3 / 2));
                h.name = new TextView(FolderActivity.this);
                h.name.setTextColor(0xFFF4EFE6);
                h.name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                h.name.setMaxLines(2);
                h.name.setPadding(dp(2), dp(6), dp(2), 0);
                box.addView(h.name, new LinearLayout.LayoutParams(cw, -2));
                box.setTag(h);
                v = box;
            } else {
                h = (Holder) v.getTag();
            }
            final Net.Entry e = items.get(p);
            final Holder fh = h;
            h.key = e.url;
            String t = Net.clean(e.name, !e.folder);
            h.name.setText(t);
            boolean short_ = t.codePointCount(0, t.length()) <= 8;
            h.ini.setText(short_ ? t : t.substring(0, t.offsetByCodePoints(0, 1)));
            h.ini.setTextSize(TypedValue.COMPLEX_UNIT_SP, short_ ? 24 : 50);
            int hu = MainActivity.hue(e.name);
            GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{
                Color.HSVToColor(new float[]{hu, 0.65f, 0.65f}),
                Color.HSVToColor(new float[]{(hu + 50) % 360, 0.75f, 0.30f})});
            bg.setCornerRadius(dp(12));
            h.poster.setBackground(bg);
            h.img.setImageBitmap(null);
            if (e.poster != null) {
                setPoster(fh, e.url, e.poster);
            } else if (e.folder) {
                Net.POOL.execute(new Runnable() {
                    @Override public void run() {
                        String pu = Net.firstImage(e.url);
                        if (pu != null) setPoster(fh, e.url, pu);
                    }
                });
            }
            return v;
        }
    }

    private void setPoster(final Holder h, final String key, final String pu) {
        Bitmap c = Net.BMP.get(pu);
        if (c != null) { if (key.equals(h.key)) h.img.setImageBitmap(c); return; }
        Net.POOL.execute(new Runnable() {
            @Override public void run() {
                try {
                    final Bitmap bm = Net.bitmap(pu, cw);
                    if (bm == null) return;
                    Net.BMP.put(pu, bm);
                    runOnUiThread(new Runnable() {
                        @Override public void run() { if (key.equals(h.key)) h.img.setImageBitmap(bm); }
                    });
                } catch (Exception ignored) { }
            }
        });
    }
}
