package com.movietv;

import android.app.Activity;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class PlayerActivity extends Activity {
    private VideoView video;
    private TextView msg;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        video = new VideoView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1);
        lp.gravity = Gravity.CENTER;
        root.addView(video, lp);

        msg = new TextView(this);
        msg.setText("লোড হচ্ছে...");
        msg.setTextColor(0xFFFFFFFF);
        msg.setTextSize(24);
        root.addView(msg, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setContentView(root);

        MediaController mc = new MediaController(this);
        mc.setAnchorView(video);
        video.setMediaController(mc);
        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer mp) { msg.setVisibility(android.view.View.GONE); }
        });
        video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                msg.setVisibility(android.view.View.VISIBLE);
                msg.setText("ভিডিও চালানো যাচ্ছে না। ফাইলটি MP4 (H.264) কি না দেখুন।");
                return true;
            }
        });
        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override public void onCompletion(MediaPlayer mp) { finish(); }
        });
        video.setVideoURI(Uri.parse(getIntent().getStringExtra("url")));
        video.requestFocus();
        video.start();
    }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (video.isPlaying()) video.pause(); else video.start();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                video.seekTo(Math.min(video.getDuration(), video.getCurrentPosition() + 10000));
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                video.seekTo(Math.max(0, video.getCurrentPosition() - 10000));
                return true;
        }
        return super.onKeyDown(code, e);
    }

    @Override protected void onDestroy() { video.stopPlayback(); super.onDestroy(); }
}
