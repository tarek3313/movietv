package com.movietv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // ===== সার্ভারের হোম পেজের ঠিকানা (ক্যাটাগরির বোতামগুলো যেখানে আছে) =====
    static final String SERVER = "http://172.16.50.4/";

    static final int BG = 0xFF0B0F1A, GOLD = 0xFFF5B335, WHITE = 0xFFFFFFFF, DIM = 0xFF9AA8C0;

    private final List<Net.Entry> cats = new ArrayList<Net.Entry>();
    private GridView grid;
    private TextView status;

    static boolean isVideo(String url) {
        String u = url.toLowerCase();
        int q = u.indexOf('?'); if (q > 0) u = u.substring(0, q);
        return u.matches(".*\\.(mp4|m4v|mkv|webm|3gp|mov|avi|ts|m3u8)$");
    }

    static int hue(String s) {
        int h = 0;
        for (int i = 0; i < s.length(); i++) h = (h * 31 + s.charAt(i)) % 360;
        return h;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(32);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView title = new TextView(this);
        title.setText("মুভি টিভি");
        title.setTextColor(GOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(pad, dp(20), pad, dp(4));
        root.addView(title);

        status = new TextView(this);
        status.setText("লোড হচ্ছে...");
        status.setTextColor(DIM);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        status.setPadding(pad, dp(10), pad, 0);
        root.addView(status);

        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(16));
        grid.setVerticalSpacing(dp(16));
        grid.setPadding(pad, dp(14), pad, dp(24));
        grid.setClipToPadding(false);
        grid.setVerticalScrollBarEnabled(false);
        GradientDrawable sel = new GradientDrawable();
        sel.setColor(0x33F5B335);
        sel.setStroke(dp(4), GOLD);
        sel.setCornerRadius(dp(14));
        grid.setSelector(sel);
        grid.setDrawSelectorOnTop(true);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                Net.Entry e = cats.get(pos);
                Intent i = new Intent(MainActivity.this, FolderActivity.class);
                i.putExtra("url", e.url);
                i.putExtra("title", e.name);
                startActivity(i);
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);
        load();
    }

    private void load() {
        Net.POOL.execute(new Runnable() {
            @Override public void run() {
                List<Net.Entry> list = null;
                try { list = Net.links(Net.get(SERVER), SERVER); } catch (Exception ignored) { }
                final List<Net.Entry> res = list;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isFinishing()) return;
                        if (res == null) { status.setText("সার্ভারে সংযোগ হচ্ছে না। টিভি আর সার্ভার একই ওয়াইফাইয়ে আছে কি না দেখুন।"); return; }
                        if (res.isEmpty()) {
                            Intent i = new Intent(MainActivity.this, WebActivity.class);
                            i.putExtra("url", SERVER);
                            startActivity(i);
                            status.setText("ক্যাটাগরির তালিকা পড়া যায়নি, তাই ওয়েব পেজ খোলা হয়েছে।");
                            return;
                        }
                        cats.addAll(res);
                        status.setVisibility(View.GONE);
                        grid.setAdapter(new BaseAdapter() {
                            @Override public int getCount() { return cats.size(); }
                            @Override public Object getItem(int p) { return cats.get(p); }
                            @Override public long getItemId(int p) { return p; }
                            @Override public View getView(int p, View v, ViewGroup parent) {
                                String name = cats.get(p).name;
                                int h = hue(name);
                                GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{
                                    Color.HSVToColor(new float[]{h, 0.60f, 0.60f}),
                                    Color.HSVToColor(new float[]{(h + 50) % 360, 0.70f, 0.30f})});
                                bg.setCornerRadius(dp(14));
                                FrameLayout f = new FrameLayout(MainActivity.this);
                                f.setLayoutParams(new GridView.LayoutParams(-1, dp(96)));
                                f.setBackground(bg);
                                TextView t = new TextView(MainActivity.this);
                                t.setText(name);
                                t.setTextColor(WHITE);
                                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                                t.setTypeface(Typeface.DEFAULT_BOLD);
                                t.setGravity(Gravity.CENTER);
                                t.setPadding(dp(10), 0, dp(10), 0);
                                f.addView(t, new FrameLayout.LayoutParams(-1, -1));
                                return f;
                            }
                        });
                        grid.requestFocus();
                    }
                });
            }
        });
    }
}
